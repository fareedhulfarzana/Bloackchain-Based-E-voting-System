# Blockchain-Based E-Voting System

Academic prototype using Python, Flask, SQLite/SQLAlchemy, HTML, CSS and JavaScript.

## Project structure

- `app.py` — Flask routes, database models and hash-linked vote-record logic
- `requirements.txt` — Python dependencies
- `templates/` — HTML/Jinja templates used by the Flask application
- `static/styles.css` — shared stylesheet
- `.gitignore` — excludes local databases, uploads, recorded videos and environment files

## Current status

**Not yet verified as a working end-to-end application.** `templates/voting_page.html` has been added because `app.py` references it. The voting page and backend still have issues that need debugging, including the webcam/video submission flow and a mismatch between the frontend's form data and the backend's required upload fields.

The code contains a basic hash-linked vote-record structure, but this is not a secure or production-ready blockchain election system. Do not use real voter identities, Aadhaar details, real elections, or real recorded video with this prototype.

## Stack found in the supplied source

- Python
- Flask
- Flask-SQLAlchemy / SQLAlchemy
- SQLite (configured in the Flask app)
- HTML, CSS and JavaScript
- JSON file storage for the hash-linked vote records
- SHA-256 hashing
- OpenCV is imported, but its use in a functioning feature has not been verified
- Flask-Mail is listed/configured, but the supplied OTP routes print OTPs to the terminal rather than sending them by email

## Setup for local testing

1. Install Python 3.10 or later.
2. Create a virtual environment.
3. Install dependencies: `pip install -r requirements.txt`.
4. Review the placeholder secret and mail configuration in `app.py` before running.
5. Run only with synthetic test data and debug the full registration-to-voting flow before describing the app as working.

This is an educational prototype, not an election-ready system.
